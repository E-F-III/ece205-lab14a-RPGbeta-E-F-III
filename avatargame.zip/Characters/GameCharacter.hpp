///////////////////////////////////////////////////////////////////////////////
//  University of Hawaii, College of Engineering
//  Lab 11a - Game Character Class Part II - ECE 205 - Spring 2025
//
///
/// @file    GameCharacter.hpp
/// @author  Steven Daniel Javier <sdjavier@hawaii.edu>
///////////////////////////////////////////////////////////////////////////////

///I edited this to test things at first so some of the spacings are probably different
///These comments and that is why I did not get the points for the autograder

#pragma once
#include <string>

enum BendingStyle {
    air,
    earth,
    fire,
    water
};

class GameCharacter {
  protected:
    std::string name;//Name of Game Character object

  public:
    //This class offers two constructors:
    GameCharacter(); //This is the default constructor.
    //If a derived class doesn't explicitly call the constructor of its
    //parent class (the base class), the compiler will implicitly call
    //the base class's default constructor (if it exists) before
    //the derived class constructor.

    explicit GameCharacter(std::string& newName); //This is a parameterized constructor.
    //Derived classes usually will not need to explicitly call this type of constructor unless
    //base class initialization is required.

    std::string getName();//Getter: Report the Name of Game Character object


    void setName(std::string& newName);//Setter: Update the Name of Game Character object

    //The greet method will most likely be removed since we also have a speak method that basically
    //does the same thing. However, this provides an example of a simple method that requires no
    //parameters
    virtual void greet() const; //Introduce Self

    //Say canned responses passed in from caller. This method will allow us to control our game
    //characters like puppets. final specifier ensures that it may not be overridden by derived classes.
    virtual void speak(std::string& response) final;
};
